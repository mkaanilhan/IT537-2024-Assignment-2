<template>
    <div class="w-full p-6 bg-gray-800 rounded-xl">
        <h2 class="text-2xl mb-4  text-gray-200">Stats</h2>
        <table class="w-full">
            <tbody>
                <tr v-for="(value, key) in param" :key="key" class="text-gray-200">
                    <td class="flex"> {{ key }} </td>
                    <td class="flex items-center justify-center min-w-48 min-h-8"> 
                        <ProgressBarComponent :progress="value" /> 
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>

    import ProgressBarComponent from '../labels/ProgressBarComponent.vue'

    export default {

        name: 'StatsComponent',

        components: {
            ProgressBarComponent
        },
        props: {
            param: {
                type: Object,
                required: true
            }
        }
    }
</script>

<style scoped>
</style>
